#!/bin/bash
usage()
{
cat << EOF
usage: $0 options

This script will retrieve basic information for all hosts registered
with vCenter. This is designed to be used in conjuction with StatsFeeder
to provide the mainly static data regarding the available hosts

OPTIONS:
   -?      Show this message
   -h      The vCenter IP address or hostname
   -u      vCenter user name
   -p      vCenter password
   -o      Output file (default: hostInventory.csv)
EOF
}

STATSFEEDER_DIR=`dirname $0`
LIB_DIR=${STATSFEEDER_DIR}/lib

VCENTER=
USER=
PASSWD=
OUTPUT=
while getopts h:b:u:p:o: OPTION
do
     case $OPTION in
         h)
             VCENTER=$OPTARG
             ;;
         u)
             USER=$OPTARG
             ;;
         p)
             PASSWD=$OPTARG
             ;;
         o)
             OUTPUT=$OPTARG
             ;;
         ?)
             usage
             exit 1
             ;;
     esac
done

if [[ -z $USER ]] || [[ -z $PASSWD ]] || [[ -z $VCENTER ]]
then
     usage
     exit 1
fi

CLASSPATH=$(JARS=("$LIB_DIR"/*.jar); IFS=:; echo "${JARS[*]}")

java -cp $CLASSPATH:. com.vmware.statsfeeder.tools.GetHostProps ${VCENTER} ${USER} ${PASSWD} ${OUTPUT}
