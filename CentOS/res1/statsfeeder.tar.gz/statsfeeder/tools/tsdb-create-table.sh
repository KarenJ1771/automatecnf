TSDB_HOME=/usr/local/opentsdb
env COMPRESSION=none HBASE_HOME=/usr/local/hbase $TSDB_HOME/src/create_table.sh

